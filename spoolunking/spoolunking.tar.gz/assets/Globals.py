import pygame
from pygame.locals import *

# Creates List of Global Variables

# Standard Screen Resolution
SCREEN_WIDTH = 1280
SCREEN_HEIGHT = 720

# Creates the Screen — 1280x720 (16:9) for browser/WASM compatibility
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT), RESIZABLE)
pygame.display.set_caption("Spoolunking — The Tangled Caves")

Running = True

# Sets Room Code
Room = -1
