import pygame
from pygame.locals import *

# Creates List of Global Variables

# Standard Screen Resolution
SCREEN_WIDTH = 1500
SCREEN_HEIGHT = 700

# Creates the Screen
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT), RESIZABLE)
pygame.display.set_caption("Spoolunking — The Tangled Caves")

Running = True

# Sets Room Code
Room = -1
