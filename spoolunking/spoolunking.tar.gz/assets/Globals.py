import pygame
from pygame.locals import *

# Creates List of Global Variables

# Standard Screen Resolution

SCREEN_WIDTH = 1280
SCREEN_HEIGHT = 720

# Creates the Screen
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT), RESIZABLE)

Running = True

# Sets Room Code
Room = -1

# ── Expansion globals ─────────────────────────────────────────────────
current_level = 1
MAX_LEVEL = 3
player_dead = False
initial_enemy_count = 0
