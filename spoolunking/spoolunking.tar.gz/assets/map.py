# Spoolunking — The Tangled Caves
# Full dungeon map for Nathan Janit's Spoolunking
#
# Tile key:
#   0  = empty floor
#   1,2,3,4 = torch (Left, Right, Up, Down)
#   5  = solid wall block
#   6  = string block (semi-solid platform)
#   ("W", hp, atk, spd, sight) = Wine enemy
#   ("C", hp, atk, spd, sight) = Cat enemy
#   ("S", hp, atk, spd, sight, color, size) = Slime enemy
#   "spawn" = player start position

def _make():
    W, H = 65, 35
    m = [[5] * W for _ in range(H)]

    def fill(r1, c1, r2, c2, v=0):
        for r in range(r1, r2 + 1):
            for c in range(c1, c2 + 1):
                if 0 < r < H - 1 and 0 < c < W - 1:
                    m[r][c] = v

    def put(r, c, v):
        if 0 < r < H - 1 and 0 < c < W - 1:
            m[r][c] = v

    # ══════════════════════════════════════════════════════════
    #  UPPER TIER  (rows 1-9)
    # ══════════════════════════════════════════════════════════

    # ── Room 0: The Woolworks (spawn room) ────────────────────
    fill(1, 1, 8, 7)
    put(2, 2, "spawn")
    put(1, 6, 2)                                    # torch →
    put(8, 1, 3)                                    # torch ↑
    put(3, 5, ("S",  5, 1, 1, 128, "Red",   1))
    put(6, 3, ("S",  5, 1, 1, 128, "Green", 1))

    # ── Room 1: The String Caverns ────────────────────────────
    fill(1, 9, 8, 21)
    put(2, 12, 2); put(2, 19, 1)
    for c in [10, 11, 12, 13, 14, 15]: put(4, c, 6)
    for c in [17, 18, 19, 20]:         put(3, c, 6)
    for c in [11, 12, 13]:             put(6, c, 6)
    put(2, 10, ("S",  7, 1, 1, 128, "Green", 2))
    put(5, 19, ("S",  7, 1, 1, 128, "White", 2))
    put(7, 14, ("S",  7, 1, 1, 128, "Red",   1))

    # ── Room 2: Torchlit Hall ─────────────────────────────────
    fill(1, 23, 8, 40)
    put(1, 25, 2); put(1, 39, 1); put(8, 32, 3)
    put(3, 27, ("W", 10, 2, 1, 160))
    put(6, 35, ("W", 10, 2, 1, 160))
    put(3, 38, ("S",  6, 1, 1, 128, "Green", 2))
    put(6, 25, ("S",  6, 1, 1, 128, "Red",   2))
    for c in [25, 26, 27]: put(5, c, 6)
    for c in [32, 33, 34]: put(4, c, 6)

    # ── Room 3: The High Fortress ─────────────────────────────
    fill(1, 42, 8, 63)
    put(1, 45, 2); put(1, 62, 1); put(8, 53, 3)
    put(3, 47, ("W", 12, 2, 1, 160))
    put(3, 58, ("C", 12, 2, 1, 160))
    put(7, 45, ("S",  8, 1, 1, 128, "White", 2))
    put(7, 60, ("W", 12, 2, 1, 160))
    put(5, 55, ("C", 12, 2, 1, 160))
    for c in [44, 45, 46, 47]: put(5, c, 6)
    for c in [53, 54, 55, 56]: put(4, c, 6)
    for c in [60, 61, 62, 63]: put(3, c, 6)

    # Upper corridors (horizontal)
    fill(4, 7,  5, 9)   # Room0 → Room1
    fill(4, 21, 5, 23)  # Room1 → Room2
    fill(4, 40, 5, 42)  # Room2 → Room3

    # Down shafts: upper tier → middle tier
    fill(8, 4,  10, 5)   # Room0 → Room4
    fill(8, 15, 10, 16)  # Room1 → Room5
    fill(8, 32, 10, 33)  # Room2 → Room6
    fill(8, 54, 10, 55)  # Room3 → Room7

    # ══════════════════════════════════════════════════════════
    #  MIDDLE TIER  (rows 10-20)
    # ══════════════════════════════════════════════════════════

    # ── Room 4: The Wine Cellar ───────────────────────────────
    fill(10, 1, 20, 12)
    put(10, 2, 2); put(10, 11, 1); put(20, 6, 4)
    put(12,  3, ("W", 12, 2, 1, 160))
    put(12,  9, ("W", 12, 2, 1, 160))
    put(17,  3, ("W", 14, 2, 1, 160))
    put(17,  9, ("W", 14, 2, 1, 160))
    put(19,  6, ("S",  8, 1, 2, 128, "Red",   2))
    for c in [2, 3, 4]:        put(15, c, 6)
    for c in [8, 9, 10, 11]:   put(14, c, 6)

    # ── Room 5: The Pit ───────────────────────────────────────
    fill(10, 14, 20, 27)
    put(10, 16, 2); put(10, 26, 1); put(20, 21, 4)
    put(11, 14, ("C", 12, 2, 1, 160))
    put(11, 26, ("W", 12, 2, 1, 160))
    put(16, 18, ("C", 14, 2, 1, 160))
    put(16, 24, ("W", 14, 2, 1, 160))
    put(19, 15, ("S", 10, 1, 2, 128, "Green", 2))
    put(19, 26, ("C", 12, 2, 1, 160))
    for c in [15, 16, 17]: put(14, c, 6)
    for c in [22, 23, 24]: put(13, c, 6)

    # ── Room 6: Cat Warren ────────────────────────────────────
    fill(10, 29, 20, 45)
    put(10, 31, 2); put(10, 44, 1); put(20, 38, 4)
    put(12, 30, ("C", 12, 2, 1, 160))
    put(12, 37, ("C", 14, 2, 1, 160))
    put(12, 44, ("C", 12, 2, 1, 160))
    put(18, 32, ("C", 14, 2, 1, 160))
    put(18, 43, ("W", 14, 2, 1, 160))
    put(15, 38, ("C", 16, 2, 1, 160))
    for c in [30, 31, 32]:      put(15, c, 6)
    for c in [38, 39, 40]:      put(14, c, 6)
    for c in [41, 42, 43, 44]:  put(17, c, 6)

    # ── Room 7: The Slime Nest ────────────────────────────────
    fill(10, 47, 20, 63)
    put(10, 50, 2); put(10, 62, 1); put(20, 56, 4)
    nest = [
        (12, 48, ("S",  8, 1, 2, 128, "Red",   1)),
        (12, 55, ("S",  9, 1, 2, 128, "Green", 1)),
        (12, 62, ("S",  8, 1, 2, 128, "White", 2)),
        (17, 50, ("S", 10, 1, 2, 128, "Red",   2)),
        (17, 58, ("S",  9, 1, 2, 128, "Green", 2)),
        (19, 54, ("S", 10, 1, 2, 128, "White", 1)),
    ]
    for r, c, v in nest:
        put(r, c, v)
    for c in [48, 49, 50, 51]: put(15, c, 6)
    for c in [55, 56, 57, 58]: put(12, c, 6)
    for c in [61, 62, 63]:     put(16, c, 6)

    # Middle corridors (horizontal)
    fill(15, 12, 16, 14)  # Room4 → Room5
    fill(15, 27, 16, 29)  # Room5 → Room6
    fill(15, 45, 16, 47)  # Room6 → Room7

    # Down shafts: middle tier → boss tier
    fill(20, 20, 22, 21)  # Room5 → Boss
    fill(20, 37, 22, 38)  # Room6 → Boss
    fill(20, 55, 22, 56)  # Room7 → Boss

    # ══════════════════════════════════════════════════════════
    #  BOSS TIER  (rows 22-33) — The Final Tangle
    # ══════════════════════════════════════════════════════════
    fill(22, 2, 33, 63)
    put(22,  5, 2); put(22, 62, 1); put(33, 33, 3)

    # Load-bearing pillars — arena structure
    for r in [24, 25]:
        for c in [10, 11]: put(r, c, 5)
        for c in [53, 54]: put(r, c, 5)
    for r in [29, 30]:
        for c in [29, 30]: put(r, c, 5)
        for c in [34, 35]: put(r, c, 5)
        for c in [38, 39]: put(r, c, 5)

    # Boss arena enemies — harder, faster versions
    put(23, 12, ("W", 20, 3, 1, 200))   # Left Wine Guard
    put(23, 52, ("W", 20, 3, 1, 200))   # Right Wine Guard
    put(26, 24, ("C", 18, 3, 2, 200))   # Left Cat Sentinel
    put(26, 40, ("C", 18, 3, 2, 200))   # Right Cat Sentinel
    put(29, 15, ("S", 22, 2, 2, 160, "Red",   2))  # Left Slime Brute
    put(29, 50, ("S", 22, 2, 2, 160, "Green", 2))  # Right Slime Brute
    put(32, 33, ("W", 40, 5, 1, 256))              # ★ FINAL BOSS ★

    # Boss room string platforms
    for c in [4,  5,  6,  7,  8,  9]:  put(27, c, 6)
    for c in [16, 17, 18, 19, 20]:     put(26, c, 6)
    for c in [44, 45, 46, 47, 48]:     put(26, c, 6)
    for c in [55, 56, 57, 58, 59]:     put(27, c, 6)
    for c in [25, 26, 27, 28]:         put(32, c, 6)
    for c in [36, 37, 38, 39]:         put(32, c, 6)

    return m


map = _make()
